class Veiculo {
  String marca;
  String modelo;
  int ano;
  String placa;
  double quilometragem;

  Veiculo({
    required this.marca,
    required this.modelo,
    required this.ano,
    required this.placa,
    required this.quilometragem,
  });
}
