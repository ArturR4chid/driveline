class Servico {
  String nome;
  double preco;
  Duration tempo;

  Servico({
    required this.nome,
    required this.preco,
    required this.tempo,
  });
}
