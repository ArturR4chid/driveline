import 'compromisso.dart';

class Agenda {
  List<Compromisso> listaCompromisso;

  Agenda({required this.listaCompromisso});
}
